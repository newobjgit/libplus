@extends('admin.layout.admin')
@section('content')
    <h3>Головна панель</h3>
@endsection