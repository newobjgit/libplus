@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                </div>
                <div class="card-header">Каталог літератур</div>
                <div class="card-header">
                    <form action="{{route('doc.store')}}" method="post" role="form" >
                        <div class="form-group">
                            <label for="MainCategories"></label>
                            <select class="form-control" id="MainCategories" size="4">
                                @foreach($maincategories as $item)
                                    <option value="{{$item->id}}">{{ $item->title }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="Categories"></label>
                            <select class="form-control" id="Categories" size="4">
                                @foreach($categories as $item)
                                    <option value="{{$item->id}}">{{ $item->title }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="SmallCategories"></label>
                            <select class="form-control" id="SmallCategories" size="4">
                                @foreach($smallcategories as $item)
                                    <option value="{{$item->id}}">{{ $item->title }}</option>
                                @endforeach
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Пошук</button>
                    </form>
                    </ol>
                </div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
