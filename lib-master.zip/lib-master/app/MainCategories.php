<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MainCategories extends Model
{
    protected $table = 'maincategories';

    public $timestamps = false;
}
