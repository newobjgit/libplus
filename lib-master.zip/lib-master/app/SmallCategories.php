<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmallCategories extends Model
{
    protected $table = 'smallcategories';

    public $timestamps = false;
}
