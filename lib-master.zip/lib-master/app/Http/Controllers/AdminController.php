<?php

namespace App\Http\Controllers;

use App\Book;
use App\Language;
use App\Source;
use App\Subject;
use App\Creator;
use App\Contributor;
use App\Publisher;
use Illuminate\Http\Request;

class AdminController extends Controller
{

    public function __construct()
    {
        $this->middleware('role:admin');
    }

    public function execute()
    {
        $data = ['title'=>'Панель адміністратора'];
        return view('admin.index',$data);
    }

    public function createDoc()
    {
        $languages = Language::all();
        $subjects = Subject::all();
        $creators = Creator::all();
        $contributors = Contributor::all();
        $publishers = Publisher::all();
        $sources = Source::all();

        return view('docs.create', [
            'languages' => $languages,
            'publishers' => $publishers,
            'contributors' => $contributors,
            'subjects' => $subjects,
            'creators' => $creators,
            'sources' => $sources,
        ]);
    }

    public function action(Request $request )
    {

        if ($request->ajax())
        {
            $query = $request->get('query');

            if ($query != '')
            {
                $books = Book::where('title','LIKE', '%'.$query.'%')->get();
            }
            else
            {
                $books = Book::all()->sortBy('updated_at');
            }

            $total_row = $books->count();

            if($total_row > 0 )
            {
                foreach ($books as $book)
                {
                    $output ='<tr><td>'.$book->title.'</td><td>'.$book->description.'</td></tr>';
                }
            }
            else
            {
                    $output ='<tr><th scope="col">Ничего не найдено</th></tr>';
            }

            $data = array(
                'table_data' => $output,
                'total_data' => $total_row
            );

            echo json_encode($data);
        }
    }


}
