<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RightManagement extends Model
{
    protected $table = 'right_managements';
}
